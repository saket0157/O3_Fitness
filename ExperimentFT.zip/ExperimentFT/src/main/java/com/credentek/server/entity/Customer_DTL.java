package com.credentek.server.entity;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Customer_BKP")
public class Customer_DTL {
	 
	 @Id
	    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cust_id_seq")
	    @SequenceGenerator(name = "cust_id_seq", sequenceName = "cust_id_seq", allocationSize = 1)
	    @Column(name = "CUST_ID")
	    private Long custId;

	    @Column(name = "FIRST_NAME")
	    private String firstName;

	    @Column(name = "LAST_NAME")
	    private String lastName;

	    @Column(name = "MOBILE_NO")
	    private String mobileNo;

	    @Column(name = "ADDRESS")
	    private String addresses;

	    @Column(name = "PAYMENT_DTL")
	    private String paymentDate;

	    @Column(name = "TOTAL_PAYMENT")
	    private String totalAmount;

	    @Column(name = "REMAINING_AMOUNT")
	    private String remainingAmount;

	    @Column(name = "EMAIL")
	    private String email;

	    @Column(name = "MEMBERSHIP")
	    private String memberships;

	    @Column(name = "CUST_BATCH")
	    private String batch;

	    @Column(name = "RENEW_PACK")
	    private String renew;

	    @Column(name = "STATUS")
	    private String active;

	    @Column(name = "IMAGE")
	    private String img;  // Assuming image is stored as a byte array (BLOB in DB)

	    @Column(name = "LAST_PAYMENT_DATE")
	    private Date lastPaymetDate;

	    @Column(name = "LAST_MEMBERSHIP")
	    private Date lastMembership;

	    @Column(name = "MEMBERSHIP_DUE_DATE")
	    private Date membershipDueDate;

		public Long getCustId() {
			return custId;
		}

		public void setCustId(Long custId) {
			this.custId = custId;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getMobileNo() {
			return mobileNo;
		}

		public void setMobileNo(String mobileNo) {
			this.mobileNo = mobileNo;
		}

		public String getAddresses() {
			return addresses;
		}

		public void setAddresses(String addresses) {
			this.addresses = addresses;
		}

		public String getPaymentDate() {
			return paymentDate;
		}

		public void setPaymentDate(String paymentDate) {
			this.paymentDate = paymentDate;
		}

		public String getTotalAmount() {
			return totalAmount;
		}

		public void setTotalAmount(String totalAmount) {
			this.totalAmount = totalAmount;
		}

		public String getRemainingAmount() {
			return remainingAmount;
		}

		public void setRemainingAmount(String remainingAmount) {
			this.remainingAmount = remainingAmount;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getMemberships() {
			return memberships;
		}

		public void setMemberships(String memberships) {
			this.memberships = memberships;
		}

		public String getBatch() {
			return batch;
		}

		public void setBatch(String batch) {
			this.batch = batch;
		}

		public String getRenew() {
			return renew;
		}

		public void setRenew(String renew) {
			this.renew = renew;
		}

		public String getActive() {
			return active;
		}

		public void setActive(String active) {
			this.active = active;
		}


		public String getImg() {
			return img;
		}

		public void setImg(String img) {
			this.img = img;
		}

		public Date getLastPaymetDate() {
			return lastPaymetDate;
		}

		public void setLastPaymetDate(Date lastPaymetDate) {
			this.lastPaymetDate = lastPaymetDate;
		}

		public Date getLastMembership() {
			return lastMembership;
		}

		public void setLastMembership(Date lastMembership) {
			this.lastMembership = lastMembership;
		}

		public Date getMembershipDueDate() {
			return membershipDueDate;
		}

		public void setMembershipDueDate(Date membershipDueDate) {
			this.membershipDueDate = membershipDueDate;
		}

		@Override
		public String toString() {
			return "Customer_DTL [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName
					+ ", mobileNo=" + mobileNo + ", addresses=" + addresses + ", paymentDate=" + paymentDate
					+ ", totalAmount=" + totalAmount + ", remainingAmount=" + remainingAmount + ", email=" + email
					+ ", memberships=" + memberships + ", batch=" + batch + ", renew=" + renew + ", active=" + active
					+ ", img=" + img + ", lastPaymetDate=" + lastPaymetDate + ", lastMembership=" + lastMembership
					+ ", membershipDueDate=" + membershipDueDate + "]";
		}

		
	    
}
