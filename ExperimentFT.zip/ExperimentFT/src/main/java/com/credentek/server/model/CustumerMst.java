package com.credentek.server.model;

import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class CustumerMst {

	
	private String custId;

	private String firstName;

	private String lastName;

	private String mobileNo;

	private String addresses;

	private String paymentDate;

	private String totalAmount;

	private String remainingAmount;

	private String email;
	private String memberships;

	private String batch;

	private String renew;

	private String active;

	private String img; // For BLOB column in the database

	private Date lastPaymetDate;

	private Date lastMembership;

	private Date membershipDueDate;

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAddresses() {
		return addresses;
	}

	public void setAddresses(String addresses) {
		this.addresses = addresses;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getRemainingAmount() {
		return remainingAmount;
	}

	public void setRemainingAmount(String remainingAmount) {
		this.remainingAmount = remainingAmount;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMemberships() {
		return memberships;
	}

	public void setMemberships(String memberships) {
		this.memberships = memberships;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public String getRenew() {
		return renew;
	}

	public void setRenew(String renew) {
		this.renew = renew;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public Date getLastPaymetDate() {
		return lastPaymetDate;
	}

	public void setLastPaymetDate(Date lastPaymetDate) {
		this.lastPaymetDate = lastPaymetDate;
	}

	public Date getLastMembership() {
		return lastMembership;
	}

	public void setLastMembership(Date lastMembership) {
		this.lastMembership = lastMembership;
	}

	public Date getMembershipDueDate() {
		return membershipDueDate;
	}

	public void setMembershipDueDate(Date membershipDueDate) {
		this.membershipDueDate = membershipDueDate;
	}

	
	
}
