package com.credentek.server.repositery;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.credentek.server.entity.Customer_DTL;
import com.credentek.server.model.CustumerMst;
@Repository
public interface Customerrepositery extends JpaRepository<Customer_DTL, String>{
	
	List<Customer_DTL> findBycustId(Long custId);

	void save(CustumerMst exiMakerDtls);
	
	@Query(nativeQuery=true, value ="SELECT * FROM Customer_BKP WHERE MEMBERSHIP_DUE_DATE > SYSDATE - 3 AND MEMBERSHIP_DUE_DATE <= SYSDATE")
	public List<Customer_DTL>findbymembershipDueDate();
	
	@Query(nativeQuery=true, value ="SELECT * FROM Customer_BKP WHERE STATUS = 'Y'")
	public List<Customer_DTL>findByActiveflag();

	
}
