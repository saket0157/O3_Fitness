package com.credentek.server.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.credentek.server.entity.Customer_DTL;
import com.credentek.server.model.CustumerMst;
import com.credentek.server.service.CustomerService;

@RestController
@CrossOrigin("*")
public class CustomerController {

	public static final Logger log = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	private CustomerService customerService;
	
	
	
	@GetMapping("/getAllMember")
	public ResponseEntity<List<Customer_DTL>> getCustomerDtl() {
	    List<Customer_DTL> response = new ArrayList<>();
	    try {
	        // Assuming customerService.getCustomerDtl() fetches customer details
	        response = customerService.getCustomerDtl(); 
	    } catch (Exception e) {
	        // Correcting the log message to reflect the correct method context
	        log.error("Error in getCustomerDtl method:", e);
	        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@GetMapping("/getActiveCust")
	public ResponseEntity<List<Customer_DTL>> getActiveDtl() {
	    List<Customer_DTL> response = new ArrayList<>();
	    try {
	        // Assuming customerService.getCustomerDtl() fetches customer details
	        response = customerService.getActivecustomerDtl(); 
	    } catch (Exception e) {
	        // Correcting the log message to reflect the correct method context
	        log.error("Error in getCustomerDtl method:", e);
	        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@GetMapping("/getAlertData")
	public ResponseEntity<List<Customer_DTL>> getAlertDtl() {
	    List<Customer_DTL> response = new ArrayList<>();
	    try {
	        // Assuming customerService.getCustomerDtl() fetches customer details
	        response = customerService.getAlertDtl(); 
	    } catch (Exception e) {
	        // Correcting the log message to reflect the correct method context
	        log.error("Error in getCustomerDtl method:", e);
	        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	
	
	@PostMapping("/addCust")
	public ResponseEntity<Map<String, String>> saveUserMaker(
			@RequestBody CustumerMst inputData) {
		log.info("Inside saveUserMaker");
		String response;
		Map<String, String> responseMap = new HashMap<>();

		try {
			response = customerService.saveCustomerDtl(inputData);

			if ("ERROR".equals(response)) {
				responseMap.put("message", "Save Error");
				responseMap.put("errorMsg", "Error");
			}
			if ("Already exist".equals(response)) {
				responseMap.put("message", "Record already exists.");
				responseMap.put("errorMsg", "Error");
			} else {
				responseMap.put("message", "Record saved successfully");
				responseMap.put("errorMsg", "Success");
			}
			return ResponseEntity.ok(responseMap);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseMap.put("message", "Internal server error");
			responseMap.put("errorMsg", "Error");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
		}
	}
	@PostMapping("/updateCust")
	public ResponseEntity<Map<String, String>> updateCustomerDtl(@RequestBody CustumerMst inputData) {
		log.info("Inside updateRecord");
		String response = "";
		Map<String, String> responseMap = new HashMap<>();
		responseMap.put("errorMsg", "Error");
		try {
			response = customerService.updateCustomerDtl(inputData);

			if ("ERROR".equals(response)) {
				responseMap.put("message", "Update Error");
				responseMap.put("errorMsg", "Error");
			}
			if ("Already exist".equals(response)) {
				responseMap.put("message", "Record already exists");
				responseMap.put("errorMsg", "Error");
			} else {
				responseMap.put("message", "Record updated successfully");
				responseMap.put("errorMsg", "Success");

			}
			return ResponseEntity.ok(responseMap);
		} catch (Throwable e) {
			log.error("error updateRecord", e);
			responseMap.put("message", "Internal server error");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
		}
}
	
	@PostMapping("/renewMembership")
	public ResponseEntity<Map<String, String>> renewCustomerDtl(@RequestBody CustumerMst inputData) {
		log.info("Inside updateRecord");
		String response = "";
		Map<String, String> responseMap = new HashMap<>();
		responseMap.put("errorMsg", "Error");
		try {
			response = customerService.renewCustomerDtl(inputData);

			if ("ERROR".equals(response)) {
				responseMap.put("message", "Update Error");
				responseMap.put("errorMsg", "Error");
			}
			if ("Already exist".equals(response)) {
				responseMap.put("message", "Record already exists");
				responseMap.put("errorMsg", "Error");
			} else {
				responseMap.put("message", "Record updated successfully");
				responseMap.put("errorMsg", "Success");

			}
			return ResponseEntity.ok(responseMap);
		} catch (Throwable e) {
			log.error("error updateRecord", e);
			responseMap.put("message", "Internal server error");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
		}
}
	
	@PostMapping("/getOverdDueMember")
	public ResponseEntity<Map<String, String>> renewMembershipDtl(@RequestBody CustumerMst inputData) {
		log.info("Inside updateRecord");
		String response = "";
		Map<String, String> responseMap = new HashMap<>();
		responseMap.put("errorMsg", "Error");
		try {
			response = customerService.renewMembershipDtl(inputData);

			if ("ERROR".equals(response)) {
				responseMap.put("message", "Update Error");
				responseMap.put("errorMsg", "Error");
			}
			if ("Already exist".equals(response)) {
				responseMap.put("message", "Record already exists");
				responseMap.put("errorMsg", "Error");
			} else {
				responseMap.put("message", "Record updated successfully");
				responseMap.put("errorMsg", "Success");

			}
			return ResponseEntity.ok(responseMap);
		} catch (Throwable e) {
			log.error("error updateRecord", e);
			responseMap.put("message", "Internal server error");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
		}
}
}
