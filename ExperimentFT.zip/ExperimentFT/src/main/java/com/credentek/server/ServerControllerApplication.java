package com.credentek.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;


@EnableAsync
@SpringBootApplication
@EnableAutoConfiguration
public class ServerControllerApplication {

	private static final Logger logger=LoggerFactory.getLogger(ServerControllerApplication.class);
	
	@Autowired
	private ApplicationContext applicationContext;

	public static void main(String[] args) {
		SpringApplication.run(ServerControllerApplication.class, args);
		logger.info("*********************************");
		logger.info("O3 Fitness Application Started Successfully...");
		logger.info("*********************************");
	}
	
//	@Bean
//	public CommandLineRunner schedulingRunner(TaskExecutor executor) {
//
//		//Create Custom Thread Class object
//		ServerRunningCheckThread srct = new ServerRunningCheckThread();
//		
//		//To make this class object as Autowire capable
//		applicationContext.getAutowireCapableBeanFactory().autowireBean(srct);
//
//		return new CommandLineRunner(){
//			public void run(String... args) throws Exception {
//				executor.execute(srct);
//			}
//		};
//	}

}
