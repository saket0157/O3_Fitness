package com.credentek.server.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.credentek.server.entity.Customer_DTL;
import com.credentek.server.model.CustumerMst;
import com.credentek.server.repositery.Customerrepositery;


@Service
public class CustomerService {

	public static final Logger log = LoggerFactory.getLogger(CustomerService.class);

	@Autowired
	private Customerrepositery customerrepositery;
	
	
	public List<Customer_DTL> getCustomerDtl() {
		log.info(" Inside method getAllData : ");

		List<Customer_DTL> resultlst = new ArrayList<>();

		try {
			resultlst = customerrepositery.findAll();

		} catch (Exception e) {
			log.info("Exception : " + e);
		}
		log.info("Exit from method of serverRequest");
		return resultlst;
		
	}
	public List<Customer_DTL> getActivecustomerDtl() {
		log.info(" Inside method getActiveCustomer Data : ");

		List<Customer_DTL> resultlst = new ArrayList<>();

		try {
			resultlst = customerrepositery.findByActiveflag();

		} catch (Exception e) {
			log.info("Exception : " + e);
		}
		log.info("Exit from method of serverRequest");
		return resultlst;
	}



	public List<Customer_DTL> getAlertDtl() {
		log.info(" Inside method getAllData : ");

		List<Customer_DTL> resultlst = new ArrayList<>();

		try {
			resultlst = customerrepositery.findbymembershipDueDate();

		} catch (Exception e) {
			log.info("Exception : " + e);
		}
		log.info("Exit from method of serverRequest");
		return resultlst;
		
	}

	
	public String saveCustomerDtl(CustumerMst inputData) {
		log.info("Inside saveCustomerDtl");
		Session session = null;
	    Long newId = null;
		try {

			
			
		
			Customer_DTL securityDeployObj = new Customer_DTL();
//			if (inputData != null) {
//				List<SecureDeployRegiMstTemp> exiMakerListTmp = securityDeployTempRepo.findAll();
//				List<SecureDeployRegiMst> exiMakerListMst = securityDeployRepo.findAll();
//
//				for (SecureDeployRegiMstTemp makerElt : exiMakerListTmp) {
//					if (makerElt != null && makerElt.getAgentName().equalsIgnoreCase(userModel.getAgentName())) {
//						return "exists AgentName";
//					}
//				}
//				for (SecureDeployRegiMstTemp makerElt : exiMakerListTmp) {
//					if (makerElt.getHostName().equalsIgnoreCase(userModel.getHostName())
//							&& makerElt.getAgentIp().equalsIgnoreCase(userModel.getAgentIp())
//							&& makerElt.getAgentPort().equalsIgnoreCase(userModel.getAgentPort())) {
//						return "exists";
//					}
//				}
//				for (SecureDeployRegiMst makerEltMst : exiMakerListMst) {
//					if (makerEltMst != null && makerEltMst.getAgentName().equalsIgnoreCase(userModel.getAgentName())) {
//						return "exists AgentName";
//					}
//				}
//				for (SecureDeployRegiMst makerEltMst : exiMakerListMst) {
//					if (makerEltMst.getHostName().equalsIgnoreCase(userModel.getHostName())
//							&& makerEltMst.getAgentIp().equalsIgnoreCase(userModel.getAgentIp())
//							&& makerEltMst.getAgentPort().equalsIgnoreCase(userModel.getAgentPort())) {
//						return "exists";
//					}
//				}
			
			securityDeployObj.setAddresses(inputData.getAddresses());
			securityDeployObj.setBatch(inputData.getBatch());
			securityDeployObj.setEmail(inputData.getEmail());
			securityDeployObj.setFirstName(inputData.getEmail());
		//	securityDeployObj.setImg(inputData.getImg());
			securityDeployObj.setLastMembership(inputData.getLastMembership());
			securityDeployObj.setLastName(inputData.getLastName());
			securityDeployObj.setLastPaymetDate(inputData.getLastPaymetDate());
			securityDeployObj.setActive("Y");
			securityDeployObj.setMemberships(inputData.getMemberships());
			securityDeployObj.setMembershipDueDate(inputData.getMembershipDueDate());
			securityDeployObj.setMobileNo(inputData.getMobileNo());
			securityDeployObj.setPaymentDate(inputData.getPaymentDate());
			securityDeployObj.setRemainingAmount(inputData.getRemainingAmount());
			securityDeployObj.setRenew(inputData.getRenew());
			securityDeployObj.setTotalAmount(inputData.getTotalAmount());
			
			customerrepositery.save(securityDeployObj);
		//	log.info("Record saved successfully with ID=" + securityDeployObj.getSecureDeployTempId());
			return "success";
				
		} catch (Exception e) {
			log.error("Error while saving license key", e);
		} catch (Throwable th) {
			log.error("Unexpected error occurred", th);
		}

		return "Failed to save license key";
	}



	@Transactional
	public String updateCustomerDtl(CustumerMst inputData) {
	    log.info("Inside updateCustomerDtl");
	    try {
	        Long custId = Long.parseLong(inputData.getCustId());

	        // Fetch the list of customers based on custId
	        List<Customer_DTL> existingCustomers = customerrepositery.findBycustId(custId);

	        // If no customers are found
	        if (existingCustomers.isEmpty()) {
	            log.error("No customer found with ID " + inputData.getCustId());
	            return "Customer not found";
	        }

	        // Iterate over the list and update each customer
	        for (Customer_DTL exiMakerDtls : existingCustomers) {
	            // Set the updated fields from inputData
	        	exiMakerDtls.setAddresses(inputData.getAddresses());
				exiMakerDtls.setBatch(inputData.getBatch());
				exiMakerDtls.setEmail(inputData.getEmail());
				exiMakerDtls.setFirstName(inputData.getEmail());
				
		//		exiMakerDtls.setImg(inputData.getImg());
				exiMakerDtls.setLastMembership(inputData.getLastMembership());
				exiMakerDtls.setLastName(inputData.getLastName());
				exiMakerDtls.setLastPaymetDate(inputData.getLastPaymetDate());
				exiMakerDtls.setActive("Y");
				exiMakerDtls.setMemberships(inputData.getMemberships());
				exiMakerDtls.setMembershipDueDate(inputData.getMembershipDueDate());
				exiMakerDtls.setMobileNo(inputData.getMobileNo());
				exiMakerDtls.setPaymentDate(inputData.getPaymentDate());
				exiMakerDtls.setRemainingAmount(inputData.getRemainingAmount());
				exiMakerDtls.setRenew(inputData.getRenew());
				exiMakerDtls.setTotalAmount(inputData.getTotalAmount());
				String base64Img = inputData.getImg(); // Assuming inputData.getImg() returns a String

			

				if (base64Img != null && base64Img.length() > 0) {
				    // Check if the base64 string starts with the prefix (this is optional, but good practice)
				    if (base64Img.startsWith("data:image")) {
				        // Strip the base64 metadata prefix (e.g., "data:image/jpeg;base64,")
				        String base64Data = base64Img.split(",")[1];

				        // Set the base64 string (without the prefix) directly into the img field
				        exiMakerDtls.setImg(base64Data);  // Store the base64 string
				    } else {
				        // If no base64 metadata prefix, handle as needed (perhaps store the raw base64 data directly)
				        // In case base64Img is a raw base64 string, set it directly
				        exiMakerDtls.setImg(base64Img);  // Store the base64 string as is
				    }
				} else {
				    // Handle the case where base64Img is null or empty
				    exiMakerDtls.setImg(null);  // Set the img field to null
				}

	            // Save updated record back to the database
	            customerrepositery.save(exiMakerDtls);
	        }

	        log.info("Customer details updated successfully with ID=" + inputData.getCustId());
	        return "success";

	    } catch (Exception e) {
	        log.error("Error while updating customer details", e);
	        return "Failed to update customer details";
	    }
	}



	public String renewCustomerDtl(CustumerMst inputData) {
		log.info("Inside updateCustomerDtl");
	    try {
	        Long custId = Long.parseLong(inputData.getCustId());

	        List<Customer_DTL> existingCustomers = customerrepositery.findBycustId(custId);

	        // If no customers are found
	        if (existingCustomers.isEmpty()) {
	            log.error("No customer found with ID " + inputData.getCustId());
	            return "Customer not found";
	        }

	        for (Customer_DTL exiMakerDtls : existingCustomers) {
	            // Set the updated fields from inputData
				exiMakerDtls.setBatch(inputData.getBatch());
				exiMakerDtls.setMemberships(inputData.getMemberships());
				exiMakerDtls.setPaymentDate(inputData.getPaymentDate());
				exiMakerDtls.setRemainingAmount(inputData.getRemainingAmount());
				exiMakerDtls.setRenew(inputData.getRenew());
				exiMakerDtls.setTotalAmount(inputData.getTotalAmount());

	            // Save updated record back to the database
	            customerrepositery.save(exiMakerDtls);
	        }

	        log.info("Customer details updated successfully with ID=" + inputData.getCustId());
	        return "success";

	    } catch (Exception e) {
	        log.error("Error while updating customer details", e);
	        return "Failed to update customer details";
	    }
	}
	public String renewMembershipDtl(CustumerMst inputData) {
		  log.info("Inside updateCustomerDtl");
		    try {
		        Long custId = Long.parseLong(inputData.getCustId());
		        String membershipmonth=inputData.getMemberships();
		        String[] parts = membershipmonth.split("\\s+");
		        int month =Integer.parseInt(parts[0]);
                String renewDuedate = getMonthsAgo(month);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                
                LocalDate date = LocalDate.parse(renewDuedate, formatter);
		        // Fetch the list of customers based on custId
		        List<Customer_DTL> existingCustomers = customerrepositery.findBycustId(custId);

		        // If no customers are found
		        if (existingCustomers.isEmpty()) {
		            log.error("No customer found with ID " + inputData.getCustId());
		            return "Customer not found";
		        }

		        // Iterate over the list and update each customer
		        for (Customer_DTL exiMakerDtls : existingCustomers) {
		            // Set the updated fields from inputData
		        	exiMakerDtls.setAddresses(inputData.getAddresses());
					exiMakerDtls.setBatch(inputData.getBatch());
					exiMakerDtls.setEmail(inputData.getEmail());
					exiMakerDtls.setFirstName(inputData.getEmail());
				
			//		exiMakerDtls.setImg(inputData.getImg());
					exiMakerDtls.setLastMembership(inputData.getLastMembership());
					exiMakerDtls.setLastName(inputData.getLastName());
					exiMakerDtls.setLastPaymetDate(inputData.getLastPaymetDate());
					exiMakerDtls.setActive("Y");
					exiMakerDtls.setMemberships(inputData.getMemberships());
					exiMakerDtls.setMembershipDueDate(java.sql.Date.valueOf(date));
					exiMakerDtls.setMobileNo(inputData.getMobileNo());
					exiMakerDtls.setPaymentDate(inputData.getPaymentDate());
					exiMakerDtls.setRemainingAmount(inputData.getRemainingAmount());
					exiMakerDtls.setRenew(inputData.getRenew());
					exiMakerDtls.setTotalAmount(inputData.getTotalAmount());
					String base64Img = inputData.getImg(); // Assuming inputData.getImg() returns a String

				

					if (base64Img != null && base64Img.length() > 0) {
					    // Check if the base64 string starts with the prefix (this is optional, but good practice)
					    if (base64Img.startsWith("data:image")) {
					        // Strip the base64 metadata prefix (e.g., "data:image/jpeg;base64,")
					        String base64Data = base64Img.split(",")[1];

					        // Set the base64 string (without the prefix) directly into the img field
					        exiMakerDtls.setImg(base64Data);  // Store the base64 string
					    } else {
					        // If no base64 metadata prefix, handle as needed (perhaps store the raw base64 data directly)
					        // In case base64Img is a raw base64 string, set it directly
					        exiMakerDtls.setImg(base64Img);  // Store the base64 string as is
					    }
					} else {
					    // Handle the case where base64Img is null or empty
					    exiMakerDtls.setImg(null);  // Set the img field to null
					}

		            // Save updated record back to the database
		            customerrepositery.save(exiMakerDtls);
		        }

		        log.info("Customer details updated successfully with ID=" + inputData.getCustId());
		        return "success";

		    } catch (Exception e) {
		        log.error("Error while updating customer details", e);
		        return "Failed to update customer details";
		    }
	}
	
	 public static String getMonthsAgo(int months) {
	        // Ensure that months are within 1 to 12
	        if (months < 1 || months > 12) {
	            throw new IllegalArgumentException("Month value must be between 1 and 12.");
	        }

	        // Define the date format (change as per your input format)
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	        // Get the current date
	        LocalDate today = LocalDate.now();

	        // Subtract the given number of months
	    //    LocalDate dateMinusMonths = today.minusMonths(months);
	        LocalDate datePlusMonths = today.plusMonths(months);	
	        
	       
	        return datePlusMonths.format(formatter);
	    }





}
