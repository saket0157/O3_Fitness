package com.credentek.server.ServerRoom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerMachineApplicationTests {

	@Test
	void contextLoads() {
	}

}
